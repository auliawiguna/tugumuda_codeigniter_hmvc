<?php
class Welcome_model extends CI_Model{
    private $table = "users";

    public function message($m=''){
        echo $m;
    }
}